#AutoLogin Chrome plugin
An chrome plugin which will login NetEase Guest WIFI automatically, written by overkazaf, kid's stuff

##Usage
1. 连接 NetEase_Guest WIFI
2. 安装chrome插件
3. 打开 http://1.1.1.1/login.html
4. 在插件处进行参数配置
5. have fun